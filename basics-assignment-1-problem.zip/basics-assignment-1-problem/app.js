const app = Vue.createApp({
  data() {
    return {
      name: "Daniel",
      age: 42,
      randomNumber2: Math.random(),
      imageUrl:
        "https://media.licdn.com/dms/image/D4E03AQHUmxEbmJNp5g/profile-displayphoto-shrink_100_100/0/1711216606606?e=1721260800&v=beta&t=bsB66KZuTRIGHBTpN9F9Yi_6ALZZ3ZXMqCD2bOB4kIc",
    };
  },
  methods: {
    randomNumber() {
      return Math.random();
    },
  },
});

app.mount("#assignment");
