function App() {
  return (
    <div>
      <h1>Welcome to the course</h1>
    </div>
  );
}

export default App;
