function Form() {
  return (
    <form className="game-form">
      <input className="game-form__input" type="date" />
      <select className="game-form__select">
        <option value="">Choose a Field</option>
        <option value="little-fenway">Little Fenway</option>
        <option value="merrit-park">Merrit Park</option>
        <option value="spanish-river">Spanish River</option>
      </select>
      <input
        className="game-form__input"
        type="text"
        placeholder="Visitor Team"
      />
      <input className="game-form__input" type="text" placeholder="Home Team" />
    </form>
  );
}

export default Form;
