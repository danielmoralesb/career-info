function Actions() {
  return (
    <div className="actions">
      <button className="btn">Clear Score Board</button>
    </div>
  );
}

export default Actions;
