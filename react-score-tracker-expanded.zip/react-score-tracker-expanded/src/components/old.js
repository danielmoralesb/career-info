// function InningScore() {
//   const [score, setScore] = useState(0);
//   return (
//     <div className="score__row">
//       <span
//         className="score__num"
//         onClick={() => setScore((score) => score + 1)}
//       >
//         {score}
//       </span>
//     </div>
//   );
// }

// function VisitorTeamScore() {
//   const [runs, setRuns] = useState(0);

//   return (
//     <div className="score__row">
//       <span className="score__num">{runs}</span>
//     </div>
//   );
// }

// let inningsArrayScore = inningsArray.reduce(function (prev, current) {
//   return prev + +current.visitorTeamScore;
// });

// console.log(`Visitor Score ${inningsArrayScore}`);

// const [visitorScore, setVisitorScore] = useState([]);
// const [score, setScore] = useState(0);

// useEffect(() => {
//   setNewRunVisitor(() => scoreVisitor);
// }, [scoreVisitor]);

// useEffect(() => {
//   setNewRunVisitor(() => scoreVisitor2);
// }, [scoreVisitor2]);

// function InningScoreVisitor({ data }) {
//   // const [score, setScore] = useState(0);

//   // useEffect(() => {
//   //   setNewRun(() => score);
//   // }, [score]);

//   // let run = score;
//   // console.log("this is the recent score " + run);

//   // let [inningsArray, setUpdatedArray] = useState({});

//   // updatedArray = (id, score) => {
//   //   console.log(id, score);
//   //   setUpdatedArray(
//   //     updatedArray.map((item) => {
//   //       if (item.id === id) {
//   //         return { ...item, visitorScore: score };
//   //       } else {
//   //         return item;
//   //       }
//   //     })
//   //   );
//   // };

//   // let inningClicked = data;
//   // console.log("This is the inning that you clicked: " + inningClicked);

//   // function updateScore(inningClicked) {
//   //   setScore((score) => score + 1);

//   //   // setScore((score) => {
//   //   //   const useZero = score > 0;
//   //   //   if (useZero) setNewRun(1);
//   //   //   return useZero ? 0 : score + 1;
//   //   // });

//   //   // useEffect(() => {});

//   //   // setScore((score) => score + 1, setNewRun(score));
//   //   // setScore(
//   //   //   (score) => score + 1,
//   //   //   setNewRun((newRun) => newRun + 1)
//   //   // );
//   //   console.log("This is the inning that you clicked: " + inningClicked);
//   //   let updatedScore = score;
//   //   // console.log("This is the score: " + updatedScore);
//   //   // let tempScore = score;
//   //   // setNewRun(tempScore);
//   //   // console.log("tempRun: " + tempScore);

//   //   let updatedInnings = inningsArray.map((inning) => {
//   //     if (inningClicked === inning.id) {
//   //       // return { ...inning, score };
//   //       console.log(
//   //         "Inning clicked is equal to inning id, and this is the Inning ID: " +
//   //           inning.id +
//   //           " and this is the score: " +
//   //           updatedScore
//   //       );
//   //     }
//   //     return {
//   //       ...inning,
//   //       inning: 7,
//   //       visitorScore: 1,
//   //       homeScore: 7,
//   //     };
//   //   });
//   //   //setInningsArray(updatedInnings);

//   //   console.log(updatedInnings);

//   //   // visitorScore.push(score);
//   //   // console.log(visitorScore);

//   //   // setUpdatedArray((prevState) => {
//   //   //   return { ...prevState, ...score };
//   //   // });

//   //   // console.log(run);
//   //   // setUpdatedArray((prevState) => {
//   //   //   return { ...prevState };
//   //   // });

//   //   // setUpdatedArray = (id, visitorScore) => {
//   //   //   console.log(id, visitorScore);
//   //   // };

//   //   // setInningsArray([
//   //   //   ...inningsArray,
//   //   //   { id: score, inning: score, visitorScore: score, homeScore: score },
//   //   // ]);

//   //   // let updatedInnings = inningsArray.map((inning) => {
//   //   //   // if (inning.id === 1) {

//   //   //   // }
//   //   //   return {
//   //   //     ...inning,
//   //   //     id: 1,
//   //   //     inning: 1,
//   //   //     visitorScore: 0,
//   //   //     homeScore: 0,
//   //   //   };
//   //   // });

//   //   // setInningsArray(updatedInnings);

//   //   // console.log(data);
//   //   // console.log(inningsArray);

//   //   // console.log(inningsArray);

//   //   // return {
//   //   //   score,
//   //   // };
//   // }

//   let tempData = data;

//   return (
//     <div className="score__row">
//       <span
//         className="score__num"
//         onClick={() => {
//           console.log(tempData);
//           if (tempData === 1) {
//             console.log("This is the 7th Inning!");
//             setScoreVisitor((c) => c + 1);
//           }
//         }}
//         // onClick={() => updateScore()}
//         // onClick={click}
//         // onClick={() => setScoreVisitor((c) => c + 1)}
//         // onClick={() => {
//         //   setScore((score) => score + 1);
//         //   // updateScore(inningClicked);
//         //   // updateRun();
//         //   // setNewRun((newRun) => newRun + 1);
//         // }}
//         // onClick={() => {
//         //   setScore((score) => score + 1);
//         //   // setRun((score) => score + 1);
//         //   // updateScore();
//         // }}
//       >
//         {scoreVisitor}
//         {/* {scoreVisitor} */}
//         {/* {() => setVisitorScore((visitorScore) => score + 10)} */}
//         {/* {console.log(visitorScore)} */}
//       </span>
//     </div>
//   );
// }

// let tempScore = useRef(newRun);
// setNewRun(tempScore);
// console.log("tempRun: " + tempScore);

// componentDidUpdate(prevProps) {

// }

// console.log("NEW RUN OUTSIDE setNewRun: " + newRun);
// let [localScore, setLocalScore] = useState(1);

// function updateScore() {
//   console.log("update score");

//   let localScore1 = Number(localScore);
//   console.log(localScore1);

//   setLocalScore((ls) => ls + 1);
//   // setScoreVisitor((score) => score + 1);
// }

// function VisitorRun(props) {
//   // setRun((score) => score + 1);
//   return <div>{props.scoreboard}</div>;
// }

// function InningDisplay(score) {
//     const [newRun, setNewRun] = useState(0);
//     return (
//       <div className="score__wrapper">
//         <div className="score__mask">
//           <div className="score__section score__section--innings">
//             {/* {innings} */}
//             {inningsArray.map((item) => {
//               return (
//                 <div className="score__col" key={item.id}>
//                   <div className="score__row">
//                     <h2 className="score__heading">{item.inning}</h2>
//                   </div>
//                   {/* <span onClick={() => setScore((c) => c + 1)}>Click</span> */}
//                   {/* <InningScoreVisitor
//                     data={item.inning}
//                     newRun={newRun}
//                     setNewRun={setNewRun}
//                   /> */}
//                   {/* <div className="score__row">
//                     <span
//                       className="score__num"
//                       onClick={() => setScoreVisitor((c) => c + 1)}
//                     >
//                       {scoreVisitor}
//                     </span>
//                   </div> */}
//                   <InningScoreVisitor data={item.inning} />
//                   <InningScoreHome data={item.inning} />
//                   {/* <InningScoreHome data={item.inning} /> */}
//                 </div>
//               );
//             })}
//           </div>
//         </div>
//       </div>
//     );
//   }

// function RunsHistsErrorsDisplay({ newRunVisitor, newRunHome }) {
//     // console.log("THIS IS THE NEW RUN in RUNSSSS: " + newRun);
//     return (
//       <div className="score__section">
//         <div className="score__col">
//           <div className="score__row">
//             <h2 className="score__heading">R</h2>
//           </div>
//           <div className="score__row">
//             <span className="score__num">
//               <span className="score__num">{newRunVisitor}</span>
//               {/* {newRun ? (
//                 {newRun}
//               )} */}
//               {/* <span className="score__num">{newRun}</span> */}
//             </span>
//           </div>
//           <div className="score__row">
//             <span className="score__num">{newRunHome}</span>
//           </div>
//         </div>
//         <div className="score__col">
//           <div className="score__row">
//             <h2 className="score__heading">H</h2>
//           </div>
//           <div className="score__row">
//             <span className="score__num">0</span>
//           </div>
//           <div className="score__row">
//             <span className="score__num">0</span>
//           </div>
//         </div>
//         <div className="score__col">
//           <div className="score__row">
//             <h2 className="score__heading">E</h2>
//           </div>
//           <div className="score__row">
//             <span className="score__num">0</span>
//           </div>
//           <div className="score__row">
//             <span className="score__num">0</span>
//           </div>
//         </div>
//       </div>
//     );
//   }

// const innings = inningsArray.map((item) => {
//   return (
//     <div className="score__col" key={item.id}>
//       <div className="score__row">
//         <h2 className="score__heading">{item.inning}</h2>
//       </div>
//       <InningScore />
//       <InningScore />
//     </div>
//   );
// });
// return (
//     <>
//       <div className="score">
//         {/* <>
//         <p>Score: {score}</p>
//         <button onClick={() => setScore((c) => c + 1)}>+</button>
//         <p>Runs: {newRun}</p>
//       </> */}
//         <TeamDisplay />
//         <InningDisplay />
//         <RunsHistsErrorsDisplay
//           newRunVisitor={newRunVisitor}
//           newRunHome={newRunHome}
//         />
//         <Counter initialCount={1} />
//       </div>
//       <Actions />
//     </>
//   );
// }
