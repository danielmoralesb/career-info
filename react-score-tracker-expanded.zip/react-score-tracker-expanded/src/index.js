import React from "react";
import ReactDOM from "react-dom/client";
import "./App.scss";

import Header from "./components/header";
import Form from "./components/form";
import Score from "./components/score";
// import Actions from "./components/actions";

const el = document.getElementById("root");
const root = ReactDOM.createRoot(el);

function App() {
  return (
    <section className="game">
      <Header />
      <Form />
      <Score />
      {/* <Actions /> */}
    </section>
  );
}

root.render(<App />);
