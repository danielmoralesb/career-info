const app = new Vue ({
    el: '#app',
    data: {
        title: 'Really Importan News',
        summary: 'This is a summary of what this news article is about.',
        votes: 0,
        thumbnail: 'http://www.lorempixel.com/100/100',
    },
    methods: {
        increment: function() {
            this.votes++;
        },
        decrement: function() {
            this.votes--;
        }
    }
});