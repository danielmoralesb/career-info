<template>
    <p>This is the Blog</p>
</template>

<script>

</script>