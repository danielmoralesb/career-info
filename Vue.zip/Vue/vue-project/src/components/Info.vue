<template>
    <div id="info">
        <p>This is the info that {{ user }} created</p>
    </div>
</template>

<script>
    export default {
        data () {
            return {
                user: 'Daniel'
            }
        }
    }
</script>

<style scoped>
    p {
        font-weight: bold;
    }
</style>