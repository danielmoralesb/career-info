import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://vwqvzvtwodendetdkafy.supabase.co";
const supabaseKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ3cXZ6dnR3b2RlbmRldGRrYWZ5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2NzgyMjAwMTYsImV4cCI6MTk5Mzc5NjAxNn0.6Q-EONjh9P2dC5kzSPOLWCefRPTDTWnzwbXOcKpH_PE";
const supabase = createClient(supabaseUrl, supabaseKey);

export default supabase;
