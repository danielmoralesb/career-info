function ProfileCard({ title, handle }) {
  return (
    <>
      <h1>{title}</h1>
      <p>{handle}</p>
    </>
  );
}

export default ProfileCard;
