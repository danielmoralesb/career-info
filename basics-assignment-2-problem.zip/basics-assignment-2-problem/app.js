const app = Vue.createApp({
  data() {
    return {
      counter: 0,
      output: "",
    };
  },
  methods: {
    showAlert() {
      alert("Hello!");
    },
    showOutput(event) {
      this.output = event.target.value;
    },
    confirmOutput2() {
      this.output2 = this.output;
    },
  },
});

app.mount("#assignment");
