const app = Vue.createApp({
  data() {
    return {
      user1: false,
      user2: false,
    };
  },
  //   computed: {
  //     user1() {
  //       return this.paragraphClass === "user1" ? "user1" : "user2";
  //     },
  //   },
  methods: {
    updateParagraphClass(event) {
      this.paragraphClass = event.target.value;
      console.log(this.paragraphClass);
    },
    toggleParagraph() {
      this.paragraphClass = !this.paragraphClass;
    },
  },
});

app.mount("#assignment");
