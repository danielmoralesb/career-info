const app = Vue.createApp({
  data() {
    return {
      counter: 0,
      name: "",
      lastName: "",
      confirmedName: "",
      fullname: "",
    };
  },
  watch: {
    counter(value) {
      if (value > 50) {
        const that = this;
        setTimeout(function () {
          that.counter = 0;
        }, 2000);
      }
    },
    // name(value) {
    //   this.fullname = value === "" ? "" : value + " " + "Morales";
    // },
  },
  computed: {
    fullname() {
      if (this.name === "" || this.lastName === "") {
        return "";
      }
      return this.name + " " + this.lastName;
    },
  },
  methods: {
    addEvent(num) {
      this.counter = this.counter + num;
    },
    removeEvent(num) {
      this.counter = this.counter - num;
      this.counter < 0 ? (this.counter = 0) : this.counter;
    },
    updateName(event) {
      this.name = event.target.value;
    },
    submitForm() {
      alert("Form Submitted!");
    },
    confirmInput() {
      this.confirmedName = this.name;
    },
    reset() {
      this.name = "";
      this.lastName = "";
    },
    outputFullname() {
      return this.name === "" ? "" : this.name + " " + "Morales";
    },
  },
});

app.mount("#events");
