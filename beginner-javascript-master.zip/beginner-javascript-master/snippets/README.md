## Html Base Snippet

This is the base HTML I use for many of the playground and exercises.

I've included it as straight html for you to copy+paste, or as a VS Code snippet as well.

Please PR this repo adding in other editor snippets as well.

## VS Code

1. Open the command palette with `⌘` or `Ctrl` + `P`
2. Type `>configure user snippets` and run the found command
3. Select `html.json` from the list
4. Paste the contents of `htmlbase.json` into the `{ }` of the file
