const p = document.querySelector('p');
console.log('im in another file');

const age = 100;
console.log(p, age);
